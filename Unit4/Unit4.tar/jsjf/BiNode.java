package jsjf;


/**
 *
 */
public class BiNode<T> extends LinearNode<T>
{
  private LinearNode<T> prev;

  public BiNode()
  {
    super();
    prev = null;
  }

  public BiNode(T elem)
  {
    super(elem);
    prev = null;
  }

  public LinearNode<T> getPrev() throws NullPointerException
  {
    return prev;
  }

  public void setPrev(LinearNode<T> node)
  {
    prev = node;
  }

}
