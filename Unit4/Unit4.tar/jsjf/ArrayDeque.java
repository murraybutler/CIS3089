package jsjf;

import jsjf.exceptions.*;
import java.util.Arrays;

public class ArrayDeque<T> implements DequeADT<T>
{
  private final static int DEF_CAP = 100;

  private int eindex, findex;
  private T[] deque;

  public ArrayDeque()
  {
    this(DEF_CAP);
    eindex = 0;
    findex = 0;
  }

  @SuppressWarnings("unchecked")
  public ArrayDeque(int initCap)
  {
    findex = 0;
    eindex = 0;
    deque = (T[])(new Object[initCap]);
  }

  public void addFirst(T element)
  {
    if (size() == deque.length) {
      expandCap();
    }

    if (findex != 0 && !isEmpty()) {
      deque[findex - 1] = element;
      findex--;
    } else if (findex != 0 && eindex != findex &&!isEmpty()) {
      for (int i = deque.length; i > 0; i--) {
        deque[i - 1] = deque[i];
      }
      deque[eindex] = element;
      eindex++;
    } else {
      deque[eindex] = element;
      eindex++;
    }
  }

  public void addLast(T element)
  {
    if (size() == deque.length) {
      expandCap();
    }

    deque[eindex] = element;
    eindex++;
  }

  public T peekFirst() throws EmptyCollectionException
  {
    return deque[findex];
  }

  public T peekLast() throws EmptyCollectionException
  {
    return deque[eindex];
  }
 
  public T removeFirst() throws EmptyCollectionException
  {
    if (isEmpty()) {
      throw new EmptyCollectionException("deque");
    }

    T ret = deque[findex];
    findex++;

    return ret;
  }

  public T removeLast() throws EmptyCollectionException
  {
    if (isEmpty()) {
      throw new EmptyCollectionException("deque");
    }

    T ret = deque[eindex];
    eindex--;

    return ret;
  }

  @Override
  public boolean isEmpty()
  {
      return size() == 0;
  }

  @Override
    public int size()
    {
      int t = eindex - findex;
      return eindex - findex;
    }

     /**
      * Private function to grow underlying array if stack grows beyond initial array size.
      * <p>
      * The size of the original array is simply doubled.
      */
     public void expandCap()
     {
      deque = Arrays.copyOf(deque, deque.length * 2);
     }
}
  
