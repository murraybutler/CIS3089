package jsjf;

import jsjf.exceptions.*;
/**
 *
 */

public interface DequeADT<T>
{

  /**
   *
   */
  public void addFirst(T element);

  /**
   *
   */
  public void addLast(T element);

  /**
   *
   */
  public T removeFirst() throws EmptyCollectionException;

  /**
   *
   */
  public T removeLast() throws EmptyCollectionException;

  /**
   *
   */
  public T peekFirst() throws EmptyCollectionException;

  /**
   *
   */
  public T peekLast() throws EmptyCollectionException;

  /**
   *
   */
  public boolean isEmpty();

  /**
   *
   */
  public int size();

  /**
   *
   */
  public String toString() throws EmptyCollectionException;

}
